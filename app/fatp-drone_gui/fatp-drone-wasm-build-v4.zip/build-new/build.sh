#!/usr/bin/env bash
set -e

# ============================================================
# fatp-drone WASM build script
# Requires: clang++-18, wasm-ld-18, wasm-opt, wasi-libc,
#           libc++-18-dev-wasm32, libc++abi-18-dev-wasm32,
#           libclang-rt-18-dev-wasm32
#
# On Ubuntu 24.04:
#   apt-get install clang-18 lld-18 binaryen wasi-libc \
#     libc++-18-dev-wasm32 libc++abi-18-dev-wasm32 \
#     libclang-rt-18-dev-wasm32
# ============================================================

FATP_INCLUDE=${FATP_INCLUDE:-"../FatP/include/fat_p"}
DRONE_INCLUDE=${DRONE_INCLUDE:-"../fatp-drone/include/drone"}
SHIMS="./shims"
LIBCXX="/usr/lib/llvm-18/include/wasm32-wasi/c++/v1"
WASI_INC="/usr/include/wasm32-wasi"
WASI_LIB="/usr/lib/wasm32-wasi"
RT_LIB="/usr/lib/llvm-18/lib/clang/18/lib/wasi/libclang_rt.builtins-wasm32.a"

CXXFLAGS="--target=wasm32-wasi -std=c++20 -O2 \
  -I${SHIMS} -I${LIBCXX} -I${WASI_INC} \
  -I${DRONE_INCLUDE} -I${FATP_INCLUDE}"

echo "==> Compiling wasm_bridge.cpp..."
clang++-18 ${CXXFLAGS} -c -o bridge.o wasm_bridge.cpp

echo "==> Compiling cxa_stubs.cpp..."
clang++-18 ${CXXFLAGS} -c -o cxa_stubs.o cxa_stubs.cpp

echo "==> Linking drone.wasm..."
wasm-ld-18 \
  bridge.o cxa_stubs.o \
  ${WASI_LIB}/libc.a \
  ${WASI_LIB}/libc++.a \
  ${WASI_LIB}/libc++abi.a \
  ${RT_LIB} \
  --no-entry \
  --export=execute_command \
  --export=execute_command_json \
  --export=free_result \
  --export=get_state_name \
  --export=malloc \
  --export=free \
  --export=__wasm_call_ctors \
  -o drone.wasm

echo "==> Optimising with wasm-opt..."
wasm-opt -O2 -o drone_opt.wasm drone.wasm
mv drone_opt.wasm drone.wasm

echo "==> Embedding into HTML..."
python3 embed_wasm.py

echo ""
echo "Done! Open fatp-drone-wasm.html in a browser."
