// Minimal C++ exception ABI stubs for WASM
// These replace the missing libc++abi symbols when compiling without a full C++ runtime.
#include <cstdlib>
#include <cstdint>

struct __cxa_exception {
    void* exceptionType;
    void (*exceptionDestructor)(void*);
    void* unexpectedHandler;
    void* terminateHandler;
    __cxa_exception* nextException;
    int handlerCount;
    int handlerSwitchValue;
    const char* actionRecord;
    const char* languageSpecificData;
    void* catchTemp;
    void* adjustedPtr;
    // exception object follows
};

extern "C" {

void* __cxa_allocate_exception(size_t size) {
    // Allocate space for the exception header + the exception object
    void* mem = malloc(sizeof(__cxa_exception) + size);
    if (!mem) abort();
    // Return pointer past the header (to where the exception object lives)
    return static_cast<char*>(mem) + sizeof(__cxa_exception);
}

void __cxa_free_exception(void* p) {
    if (p) free(static_cast<char*>(p) - sizeof(__cxa_exception));
}

[[noreturn]] void __cxa_throw(void* ex, void* type, void (*destructor)(void*)) {
    // In our single-threaded WASM environment, just abort on any exception.
    // The drone simulation should not throw under normal operation.
    (void)ex; (void)type; (void)destructor;
    abort();
}

int __cxa_thread_atexit(void (*func)(void*), void* arg, void* dso) {
    (void)func; (void)arg; (void)dso;
    return 0;
}

// Called when an exception propagates through a noexcept boundary
void __cxa_call_terminate() { abort(); }

} // extern "C"
