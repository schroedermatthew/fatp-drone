#include "CommandParser.h"
#include "DroneEvents.h"
#include "SubsystemManager.h"
#include "TelemetryLog.h"
#include "VehicleStateMachine.h"

#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <cstdio>

// Global drone simulation objects (single session, single-threaded for WASM)
static drone::events::DroneEventHub   g_hub;
static drone::SubsystemManager        g_mgr{g_hub};
static drone::VehicleStateMachine     g_sm{g_mgr, g_hub};
static drone::TelemetryLog<512>       g_log{g_hub};
static drone::CommandParser<512>      g_cmd{g_mgr, g_sm, g_log};
static bool g_initialized = false;

static void ensure_init() {
    if (!g_initialized) {
        g_log.logInfo("wasm", "session started");
        g_initialized = true;
    }
}

namespace {

struct CommandEnvelope {
    bool success = false;
    bool quit = false;
    std::string message;
};

static CommandEnvelope run_command(const std::string& line) {
    auto result = g_cmd.execute(line);
    return {result.success, result.quit, result.message};
}

static std::string state_name_copy() {
    const char* ptr = g_sm.currentStateName().data();
    return ptr ? std::string(ptr) : std::string{};
}

static std::string capture_snapshot_json() {
    const auto result = run_command("json");
    return result.success ? result.message : std::string{"null"};
}

static std::string capture_log_text() {
    const auto result = run_command("log 256");
    return result.success ? result.message : std::string{};
}

static std::vector<std::string> split_lines(const std::string& text) {
    std::vector<std::string> lines;
    std::string current;
    current.reserve(96);

    for (char ch : text) {
        if (ch == '\r') {
            continue;
        }
        if (ch == '\n') {
            if (!current.empty()) {
                lines.push_back(current);
                current.clear();
            }
            continue;
        }
        current.push_back(ch);
    }

    if (!current.empty()) {
        lines.push_back(current);
    }
    return lines;
}

static std::vector<std::string> diff_appended_lines(
    const std::string& before_text,
    const std::string& after_text
) {
    const auto before = split_lines(before_text);
    const auto after = split_lines(after_text);

    std::size_t prefix = 0;
    while (prefix < before.size() && prefix < after.size() && before[prefix] == after[prefix]) {
        ++prefix;
    }

    return std::vector<std::string>(after.begin() + static_cast<std::ptrdiff_t>(prefix), after.end());
}

static void append_json_escaped(std::string& out, const std::string& value) {
    out.push_back('"');
    for (unsigned char ch : value) {
        switch (ch) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (ch < 0x20) {
                    char buf[7];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", static_cast<unsigned>(ch));
                    out += buf;
                } else {
                    out.push_back(static_cast<char>(ch));
                }
                break;
        }
    }
    out.push_back('"');
}

static void append_json_key(std::string& out, const char* key) {
    append_json_escaped(out, key);
    out.push_back(':');
}

static void append_json_string_array(std::string& out, const std::vector<std::string>& values) {
    out.push_back('[');
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (i != 0) {
            out.push_back(',');
        }
        append_json_escaped(out, values[i]);
    }
    out.push_back(']');
}

static char* duplicate_c_string(const std::string& text) {
    char* buffer = static_cast<char*>(std::malloc(text.size() + 1));
    if (!buffer) {
        return nullptr;
    }
    std::memcpy(buffer, text.c_str(), text.size() + 1);
    return buffer;
}

static std::string build_command_json(const std::string& input) {
    const std::string state_before = state_name_copy();
    const std::string snapshot_before = capture_snapshot_json();
    const std::string log_before = capture_log_text();

    const auto result = run_command(input);

    const std::string state_after = state_name_copy();
    const std::string snapshot_after = capture_snapshot_json();
    const std::string log_after = capture_log_text();
    const auto log_delta = diff_appended_lines(log_before, log_after);

    std::string out;
    out.reserve(
        256 + input.size() + result.message.size() + snapshot_before.size() + snapshot_after.size() + log_after.size()
    );

    out.push_back('{');
    append_json_key(out, "protocol");
    append_json_escaped(out, "fatp-drone-wasm-v2");
    out.push_back(',');
    append_json_key(out, "command");
    append_json_escaped(out, input);
    out.push_back(',');
    append_json_key(out, "success");
    out += result.success ? "true" : "false";
    out.push_back(',');
    append_json_key(out, "quit");
    out += result.quit ? "true" : "false";
    out.push_back(',');
    append_json_key(out, "message");
    append_json_escaped(out, result.message);
    out.push_back(',');
    append_json_key(out, "state_before");
    append_json_escaped(out, state_before);
    out.push_back(',');
    append_json_key(out, "state_after");
    append_json_escaped(out, state_after);
    out.push_back(',');
    append_json_key(out, "snapshot_before");
    out += snapshot_before.empty() ? "null" : snapshot_before;
    out.push_back(',');
    append_json_key(out, "snapshot_after");
    out += snapshot_after.empty() ? "null" : snapshot_after;
    out.push_back(',');
    append_json_key(out, "log_delta");
    append_json_string_array(out, log_delta);
    out.push_back('}');
    return out;
}

} // namespace

// Returns a malloc'd C string - JS must call free_result() after use
extern "C" {

char* execute_command(const char* line) {
    ensure_init();
    std::string input(line ? line : "");
    const auto result = run_command(input);

    // Format: <success_char>|<quit_char>|<message>
    std::string out;
    out += (result.success ? '1' : '0');
    out += '|';
    out += (result.quit ? '1' : '0');
    out += '|';
    out += result.message;

    return duplicate_c_string(out);
}

char* execute_command_json(const char* line) {
    ensure_init();
    std::string input(line ? line : "");
    const std::string out = build_command_json(input);
    return duplicate_c_string(out);
}

void free_result(char* ptr) {
    std::free(ptr);
}

const char* get_state_name() {
    return g_sm.currentStateName().data();
}

} // extern "C"
