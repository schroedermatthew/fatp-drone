#!/usr/bin/env python3
"""
Reads drone.wasm and fatp-drone-wasm-template.html,
injects base64 WASM into the placeholder, writes fatp-drone-wasm.html.
"""
import base64, sys

with open('drone.wasm', 'rb') as f:
    b64 = base64.b64encode(f.read()).decode()

with open('fatp-drone-wasm-template.html') as f:
    html = f.read()

if 'WASM_BASE64_PLACEHOLDER' not in html:
    print("ERROR: template missing WASM_BASE64_PLACEHOLDER", file=sys.stderr)
    sys.exit(1)

html = html.replace('WASM_BASE64_PLACEHOLDER', b64)

with open('fatp-drone-wasm.html', 'w') as f:
    f.write(html)

print(f"Written fatp-drone-wasm.html ({len(html):,} bytes)")
