# fatp-drone WASM Build

Compiles the fatp-drone C++ simulator to WebAssembly and embeds it in a single-file HTML GUI.

## Files

| File | Purpose |
|------|---------|
| `wasm_bridge.cpp` | C bridge: exposes legacy `execute_command()` plus structured `execute_command_json()`, `free_result()`, `get_state_name()` as WASM exports |
| `cxa_stubs.cpp` | In-WASM `__cxa_allocate_exception` / `__cxa_throw` stubs (must live inside WASM for vtable indirect calls to resolve) |
| `shims/` | Header shims patching wasi-libc Jan 2023 vs libc++-18 mismatch |
| `fatp-drone-wasm-template.html` | GUI template with `WASM_BASE64_PLACEHOLDER` |
| `embed_wasm.py` | Injects base64 WASM into template → final HTML |
| `build.sh` | Full build pipeline |

## Shims explained

| Shim | Why needed |
|------|-----------|
| `mutex`, `shared_mutex`, `condition_variable`, `thread` | Fat-P `ConcurrencyPolicies.h` includes these unconditionally; WASM libc++ is single-threaded so they must be no-ops |
| `future` | `Expected.h` includes `<future>` for AsyncTask; needs `std::launch::async` enum |
| `fstream` | `JsonLite.h` uses `ifstream`/`ofstream`; WASM has no filesystem |
| `charconv` | Adds `from_chars(double)` via `strtod`; missing from wasi-libc 2023 |

## Prerequisites (Ubuntu 24.04)

```bash
apt-get install clang-18 lld-18 binaryen wasi-libc \
  libc++-18-dev-wasm32 libc++abi-18-dev-wasm32 \
  libclang-rt-18-dev-wasm32
```

## Usage

```bash
# Point at your Fat-P headers and fatp-drone headers
export FATP_INCLUDE=/path/to/FatP/include/fat_p
export DRONE_INCLUDE=/path/to/fatp-drone/include/drone

bash build.sh
# → fatp-drone-wasm.html (open in any browser, no server needed)
```

## How it works in the browser

1. HTML loads, decodes base64 WASM → `Uint8Array`
2. `WebAssembly.instantiate()` with WASI snapshot_preview1 shims
3. Calls `__wasm_call_ctors()` to run C++ static constructors
4. Buttons/commands prefer `execute_command_json(cmdStr)` and fall back to `execute_command(cmdStr)`
5. The bridge returns state/snapshot/log delta for exact graph highlighting after each command
6. State, subsystems, telemetry all read back from live WASM memory
